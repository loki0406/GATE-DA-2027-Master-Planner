GATE 2027 DA — SECTION 1: PROBABILITY AND STATISTICS
40 separate topic presentations

HOW TO USE
Extract this ZIP before opening files. Open INDEX.html for a clickable topic list,
or open the numbered PPTX files directly in PowerPoint or another compatible viewer.
The navy, teal, gold and off-white design follows the two earlier presentations.
Equations and explanations are editable slide text. Some mathematical symbols may
display differently if your viewer substitutes fonts; DejaVu Sans is the intended font.

STUDY METHOD
Read the concept slides. Attempt each worked-example prompt before advancing to its
solution. Complete the practice questions without notes, then review their solutions.
Use each deck's formula summary and common-error checklist for revision.
Numbering follows the supplied syllabus. Where a lesson references a later prerequisite
(for example, expectation or a density), consult that numbered deck as needed.

SCOPE AND TOPIC SPLITS
The source is DA_SYLLABUS_2025_2024.pdf, PDF page 1, Section 1.
Counting and Probability Axioms are the completed earlier decks.
Combined syllabus phrases are separated into individual decks: marginal/conditional/
joint probability; conditional expectation/variance; mean/median/mode/standard deviation;
correlation/covariance; random variables/discrete random variables/PMF.
The two occurrences of uniform are treated as discrete uniform and continuous uniform.
“Probability distribution function” in the continuous-variable sequence is covered as
the probability density function (PDF), while the separately listed CDF has its own deck.
Poisson is correctly presented as a DISCRETE distribution, regardless of its position
among distribution names in the source. Variance fundamentals also appear in the
Standard Deviation and Conditional Variance decks.

QUESTION PROVENANCE
The Counting deck retains its identified GATE 2024 question from the supplied PDF.
Other practice questions in this collection are original teaching questions and are
not claimed to be previous-year questions. Probability and inference calculations state
their model assumptions. Approximations are labelled and supplied table values are used.
This is an independent study collection, not an official IIT/GATE publication.

TOPIC INDEX
01. Counting: Permutations and Combinations — 44 slides
    01_Counting_Permutations_and_Combinations.pptx
02. Probability Axioms — 42 slides
    02_Probability_Axioms.pptx
03. Sample Space — 23 slides
    03_Sample_Space.pptx
04. Events — 23 slides
    04_Events.pptx
05. Independent Events — 23 slides
    05_Independent_Events.pptx
06. Mutually Exclusive Events — 23 slides
    06_Mutually_Exclusive_Events.pptx
07. Marginal Probability — 23 slides
    07_Marginal_Probability.pptx
08. Conditional Probability — 23 slides
    08_Conditional_Probability.pptx
09. Joint Probability — 23 slides
    09_Joint_Probability.pptx
10. Bayes’ Theorem — 23 slides
    10_Bayes_Theorem.pptx
11. Conditional Expectation — 23 slides
    11_Conditional_Expectation.pptx
12. Conditional Variance — 23 slides
    12_Conditional_Variance.pptx
13. Mean — 23 slides
    13_Mean.pptx
14. Median — 23 slides
    14_Median.pptx
15. Mode — 23 slides
    15_Mode.pptx
16. Standard Deviation — 23 slides
    16_Standard_Deviation.pptx
17. Correlation — 23 slides
    17_Correlation.pptx
18. Covariance — 23 slides
    18_Covariance.pptx
19. Random Variables — 23 slides
    19_Random_Variables.pptx
20. Discrete Random Variables — 23 slides
    20_Discrete_Random_Variables.pptx
21. Probability Mass Functions — 23 slides
    21_Probability_Mass_Functions.pptx
22. Discrete Uniform Distribution — 23 slides
    22_Discrete_Uniform_Distribution.pptx
23. Bernoulli Distribution — 23 slides
    23_Bernoulli_Distribution.pptx
24. Binomial Distribution — 23 slides
    24_Binomial_Distribution.pptx
25. Continuous Random Variables — 23 slides
    25_Continuous_Random_Variables.pptx
26. Probability Density Functions — 23 slides
    26_Probability_Density_Functions.pptx
27. Continuous Uniform Distribution — 23 slides
    27_Continuous_Uniform_Distribution.pptx
28. Exponential Distribution — 23 slides
    28_Exponential_Distribution.pptx
29. Poisson Distribution — 23 slides
    29_Poisson_Distribution.pptx
30. Normal Distribution — 23 slides
    30_Normal_Distribution.pptx
31. Standard Normal Distribution — 23 slides
    31_Standard_Normal_Distribution.pptx
32. Student’s t Distribution — 23 slides
    32_Student_s_t_Distribution.pptx
33. Chi-Squared Distribution — 23 slides
    33_Chi_Squared_Distribution.pptx
34. Cumulative Distribution Function — 23 slides
    34_Cumulative_Distribution_Function.pptx
35. Conditional PDF — 23 slides
    35_Conditional_PDF.pptx
36. Central Limit Theorem — 24 slides
    36_Central_Limit_Theorem.pptx
37. Confidence Intervals — 25 slides
    37_Confidence_Intervals.pptx
38. z-Test — 25 slides
    38_z_Test.pptx
39. t-Test — 25 slides
    39_t_Test.pptx
40. Chi-Squared Tests — 25 slides
    40_Chi_Squared_Tests.pptx

TOTAL: 40 PPTX files; 969 slides.
